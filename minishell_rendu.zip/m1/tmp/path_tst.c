#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>


int ft_strlen(char *str)
{
	int i;

	i = 0;
	while (str[i])
		i++;
	return i;
}



int main(void)
{
	char buffer[1024];
	if (getcwd(buffer, sizeof(buffer)) != NULL)
	{
		printf("%s\n%d\n", buffer, ft_strlen(buffer));
		printf("%c", buffer[ft_strlen(buffer)-2]);
	}
	return (1);
}