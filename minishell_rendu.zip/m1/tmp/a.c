#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <ncurses.h>
#include <termios.h>


typedef struct t_minishell_data
{
	int status;
	char *current_line;
	char **history;
	char **env;
	char **args;
	char *path;
	
} t_minishell_data;

char *ft_strjoin(char *s1, char *s2)
{
	char *ret;
	int i = 0;
	int j = 0;

	ret = (char *)malloc(sizeof(char) * (strlen(s1) + strlen(s2) + 1));
	while (s1[i])
	{
		ret[i] = s1[i];
		i++;
	}
	while (s2[j])
	{
		ret[i + j] = s2[j];
		j++;
	}
	ret[i + j] = '\0';
	return (ret);
}

int ft_strlen(char *str)
{
	int i = 0;
	while (str[i])
		i++;
	return (i);
}

void ft_putstr(char *str)
{
	write(1, str, ft_strlen(str));
}

void ft_putchar(char c)
{
	write(1, &c, 1);
}

char *ft_strsub(char *str, int start, int len)
{
	char *ret;
	int i = 0;

	ret = (char *)malloc(sizeof(char) * (len + 1));
	while (i < len)
	{
		ret[i] = str[start + i];
		i++;
	}
	ret[i] = '\0';
	return (ret);
}

char **ft_strsplit(char *str, char c)
{
	char **ret;
	int i = 0;
	int j = 0;
	int k = 0;
	int len = 0;

	while (str[i])
	{
		if (str[i] == c)
			len++;
		i++;
	}
	ret = (char **)malloc(sizeof(char *) * (len + 2));
	i = 0;
	while (str[i])
	{
		if (str[i] == c)
		{
			ret[j] = ft_strsub(str, k, i - k);
			j++;
			k = i + 1;
		}
		i++;
	}
	ret[j] = ft_strsub(str, k, i - k);
	ret[j + 1] = NULL;
	return (ret);
}

int get_next_line(int fd, char **line)
{
	char buf[2];
	char *tmp;
	int ret;

	*line = (char *)malloc(sizeof(char));
	*line[0] = '\0';
	while ((ret = read(fd, buf, 1)) > 0)
	{
		buf[ret] = '\0';
		if (buf[0] == '\n')
			return (1);
		tmp = *line;
		*line = ft_strjoin(*line, buf);
		free(tmp);
	}
	if (ret == 0)
		return (0);
	return (-1);
}



void ft_putnbr(int n)
{
	if (n < 0)
	{
		ft_putstr("-");
		n = -n;
	}
	if (n >= 10)
		ft_putnbr(n / 10);
	ft_putchar(n % 10 + '0');
}

void ft_loop()
{
	//attendre une frap de l'utilisateur
	//lire la frappe de l'utilisateur

	//si la frappe est "exit"
	//exit(0);

	//sinon
	//fork
	//si fils
	//execve
	//si pere
	//wait
	//afficher le resultat
	//boucle
	char *line;
	char **args;
	int status;

	while (1)
	{
		ft_putstr("minishell$> ");
		get_next_line(0, &line);
		if (strcmp(line, "exit") == 0)
			exit(0);
		args = ft_strsplit(line, ' ');
		if (fork() == 0)
		{
			execve(args[0], args, NULL);
			exit(0);
		}
		else
			wait(&status);
		ft_putnbr(status);
		ft_putstr("\n");
	}
}

void key_surveille()
{
	initscr();  // Initialisation de ncurses
    raw();      // Lecture des touches sans nécessiter l'appui sur Entrée
    keypad(stdscr, TRUE);  // Activation des touches spéciales

	int key;
	key = -1;
    while ((key = getch()) != 'q') {
        printw("Vous avez appuyé sur la touche : %c\n", key);
        refresh();  // Rafraîchit l'affichage
    }

}


void old_pos()
{
	int i;

	i = 0;
	while (i < 41)
	{
		write(1, "\b", 1);
		i++;
	}
}


void draw_cur()
{
	write(1, " =>", 3);
}
void display_menu(int cur)
{

	write(1, "========================================\n",41);
	old_pos();
	write(1, "===     BIENVENUE DANS METASHELL     ===\n",41);
	old_pos();
	write(1, "===                                  ===\n",41);
	old_pos();
	write(1, "===", 3);
	if (cur % 4 != 0)
		write(1, "   ", 3);
	else
		draw_cur();
	write(1, "- NETWORK SCAN                 ===\n",35);
	old_pos();
	write(1, "===", 3);
	if (cur % 4 != 1)
		write(1, "   ", 3);
	else
		draw_cur();

	write(1, "- PROGRAMMES LIST              ===\n",35);
	old_pos();

	write(1, "===", 3);
	if (cur % 4 != 2)
		write(1, "   ", 3);
	else
		draw_cur();
	write(1, "- ANNIMATION                   ===\n",35);
	old_pos();
	write(1, "===", 3);
	if (cur % 4 != 3)
		write(1, "   ", 3);
	else
		draw_cur();
	write(1, "- EXIT                         ===\n",35);
	old_pos();
	write(1, "===                                  ===\n",41);
	old_pos();
	write(1, "========================================\n",41);
}


void menu()
{
	int key;
	int cur;

	initscr();  // Initialisation de ncurses
	raw();      // Lecture des touches sans nécessiter l'appui sur Entrée
	keypad(stdscr, TRUE);  // Activation des touches spéciales

	cur = 0;
	key = -1;

	display_menu(cur);

	while ((key = getch()) != 'q')
	{

		//si l'utilisateur n'a pas appuyer sur une touche
		//on ne fait rien
		if (key == -1)
			continue;

		if (key == KEY_UP)
			cur--;
		if (key == KEY_DOWN)
			cur++;
		if (key == '\n')
		{
			if (cur % 4 == 0)
			{
				ft_putstr("NETWORK SCAN\n");
				system("clear");
				system("nmap -sP -V 192.168.1.0/24");
			}
			if (cur % 4 == 1)
			{
				ft_putstr("PROGRAMMES LIST\n");
				system("clear");
				//lister les programme en cours d'execution
				system("ps -aux");
			}
			if (cur % 4 == 2)
			{
				ft_putstr("ANNIMATION\n");
				//ouvrire l'url "https://www.youtube.com/watch?v=DEqXNfs_HhY&ab_channel=LexFridman"

				system("clear");
				system("google-chrome https://www.youtube.com/watch?v=DEqXNfs_HhY&ab_channel=LexFridman");
			}
			if (cur % 4 == 3)
				exit(0);
			return;
		}
		else
		{
			system("clear");
			display_menu(cur);
			printf("\n\nkey = %d\n", key);
		}

		//clear();
	}
}
int main(int argc, char **argv)
{
	menu();
	//key_surveille();
	//ft_loop();

	return (0);
}