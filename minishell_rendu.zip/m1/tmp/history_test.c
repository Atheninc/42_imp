#include <stdio.h>
#include <stdlib.h>
#include <readline/readline.h>
#include <readline/history.h>


void exec_cmd()
{

}

int main(int argc, char **argc, char **argv) {
    char* input;

    while (1) {
        input = readline("MonShell> ");
        
        if (!input) {
            // L'utilisateur a appuyé sur Ctrl+D (EOF), quitter le shell.
            break;
        }

        if (input[0] != '\0') {
            // Ajouter la commande à l'historique si elle n'est pas vide.
            add_history(input);
        }

        // Ici, vous pouvez traiter la commande input comme bon vous semble.

        // Libérer la mémoire allouée par readline.
        free(input);
    }

    // Effacer l'historique avant de quitter (facultatif).
    clear_history();

    return 0;
}
