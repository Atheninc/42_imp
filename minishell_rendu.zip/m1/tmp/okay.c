#include <stdio.h>
#include <unistd.h>

int main(void)
{
	write(1, "HELLO\n", 6);
	return (0);
}