#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <readline/readline.h>
#include <readline/history.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <sys/stat.h>

int ft_strlen(char *str)
{
	int i;

	i = 0;
	while (str[i])
		i++;
	return (i);
}

int ft_indexof(char *src, char ocu)
{
	int i;

	i = 0;
	while (src[i])
	{
		if (src[i] == ocu)
			return (i);
		i++;
	}
	return (-1);
}
char *ft_substr(char *src, int start, int len)
{
	char *dest;
	int i;

	if (!src)
		return (NULL);
	if (start > ft_strlen(src))
		return (strdup(""));
	if (len > ft_strlen(src))
		len = ft_strlen(src);
	dest = malloc(sizeof(char) * (len + 1));
	if (!dest)
		return (NULL);
	i = 0;
	while (i < len)
	{
		dest[i] = src[start + i];
		i++;
	}
	dest[i] = '\0';
	return (dest);
}

char **ft_split_path(char *src, char ocu)
{
	char **dest;
	int i;
	int j;
	int k;

	i = 0;
	j = 0;
	k = 0;
	dest = malloc(sizeof(char *) * (ft_strlen(src) + 1));
	if (!dest)
		return (NULL);
	while (src[i])
	{
		if (src[i] == ocu)
		{
			dest[j] = ft_substr(src, k, i - k);
			j++;
			k = i + 1;
		}
		i++;
	}
	dest[j] = ft_substr(src, k, i - k);
	dest[j + 1] = NULL;
	return (dest);
}

char *ft_concate(char *p1, char *p2)
{
	char *dest;
	int i;
	int j;

	dest = malloc(sizeof(char) * (ft_strlen(p1) + ft_strlen(p2) + 2));
	if (!dest)
		return (NULL);
	i = 0;
	j = 0;
	while (p1[i])
	{
		dest[i] = p1[i];
		i++;
	}
	dest[i] = '/';
	i++;
	while (p2[j])
	{
		dest[i] = p2[j];
		i++;
		j++;
	}
	dest[i] = '\0';
	return (dest);
}

void ft_execv(char *cmd)
{
	char **path_split;
	char *programPath;
	char *path;
	int i;

	i = 0;
	path = getenv("PATH");
	if (path != NULL)
	{
		path_split = ft_split_path(path, ':');
		i = 0;
		while (path_split[i])
		{
			programPath = ft_concate(path_split[i], cmd);
			char *args[] = {programPath, NULL};
			if (execve(programPath, args, NULL) == -1) {
				//perror("execve");
				//printf("error\n");
			}
			else
			{
				printf("success\n");
				return;
			}
			i++;
		}
		
	}
}

int main(int argc, char **argv)
{
	if (argc == 1)
	{
		printf("vous n'avez pas mis d'argument");
	}
	else
	{
		ft_execv(argv[1]);
	}
    return 0;
}
