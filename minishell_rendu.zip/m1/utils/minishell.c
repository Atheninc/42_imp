#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <readline/readline.h>
#include <readline/history.h>
#include <sys/wait.h>



typedef struct env_data
{
	char *elem;
	char *path;
}		t_env;

typedef struct path_data
{
	char *path;
	char **vars;
}	t_path_data;


int ft_count_env(char **env)
{
	int i;

	i = 0;
	while (env[i])
		i++;
	return (i);
}

int ft_strlen(char *str)
{
	int i;

	i = 0;
	while (str[i])
		i++;
	return (i);
}
int ft_indexof(char *str, char c)
{
	int i;

	i = 0;
	while (str[i])
	{
		if (str[i] == c)
			return (i);
		i++;
	}
	return (-1);
}

char	*ft_substr(char *str, int start, int len)
{
	char	*dest;
	int		i;

	if (!str)
		return (NULL);
	if (start > ft_strlen(str))
		return (strdup(""));
	if (len > ft_strlen(str))
		len = ft_strlen(str);
	dest = malloc(sizeof(char) * (len + 1));
	if (!dest)
		return (NULL);
	i = 0;
	while (i < len && str[start])
	{
		dest[i] = str[start];
		i++;
		start++;
	}
	dest[i] = '\0';
	return (dest);
}

t_env ft_split_env(char *src)
{
	t_env dest;
	int i;

	i = ft_indexof(src, '=');
	dest.elem = ft_substr(src, 0, i);
	dest.path = ft_substr(src, i + 1, ft_strlen(src));
	return (dest);
}

void ft_print_env(t_env *env)
{
	int i;

	i = 0;
	while (env[i].elem)
	{
		printf("[%s] = %s\n", env[i].elem, env[i].path);
		i++;
	}
}

char *parse_cmd(char *src)
{
	char *tmp;
	int n;
	int i;

	n = ft_indexof(src, ' ');
	if (n == -1)
		n = ft_strlen(src);
	tmp = (char *)malloc(sizeof(char) * (n + 1));
	if (!tmp)
		return (NULL);
	i = 0;
	while (i < n)
	{
		tmp[i] = src[i];
		i++;
	}
	tmp[i] = 0;
	return (tmp);
}

char *ft_concate(char *p1, char *p2)
{
	char *dest;
	int i;
	int j;

	dest = malloc(sizeof(char) * (ft_strlen(p1) + ft_strlen(p2) + 2));
	if (!dest)
		return (NULL);
	i = 0;
	j = 0;
	while (p1[i])
	{
		dest[i] = p1[i];
		i++;
	}
	dest[i] = '/';
	i++;
	while (p2[j])
	{
		dest[i] = p2[j];
		i++;
		j++;
	}
	dest[i] = '\0';
	return (dest);
}

char **ft_split_path(char *src, char ocu)
{
	char **dest;
	int i;
	int j;
	int k;

	i = 0;
	j = 0;
	k = 0;
	dest = malloc(sizeof(char *) * (ft_strlen(src) + 1));
	if (!dest)
		return (NULL);
	while (src[i])
	{
		if (src[i] == ocu)
		{
			dest[j] = ft_substr(src, k, i - k);
			j++;
			k = i + 1;
		}
		i++;
	}
	dest[j] = ft_substr(src, k, i - k);
	dest[j + 1] = NULL;
	return (dest);
}
int ft_strlstlen(char **lst)
{
	int i;

	i = 0;
	while (lst[i])
		i++;
	return i;
}

char **ft_concate_arg(char **tmp1, char **tmp2)
{
	int i;
	int n;
	int t;
	int c;
	char **dst;

	i = ft_strlstlen(tmp1);
	n = ft_strlstlen(tmp2);
	dst = (char **)malloc(sizeof(char *) * (i + n + 1));
	t = 0;
	c = 0;
	while (tmp1[c])
	{
		dst[c] = tmp1[c];
		t++;
		c++;
	}
	c = 0;
	while (tmp2[c])
	{
		dst[t] = tmp2[c];
		t++;
		c++;
	}
	dst[t] = NULL;
	return (dst);
}

char **ft_add_front_list(char *txt, char **lst)
{
	int i;
	char **dst;
	int s;

	s = ft_strlstlen(lst) + 2;
	dst = (char **)malloc(sizeof(char *) * s + 1);
	i = 0;
	dst[0] = txt;
	while (lst[i])
	{
		dst[i + 1] = lst[i];
		i++;
	}
	dst[i+1] = NULL;
	return dst;
}

int ft_execv(char *cmd, char **arg)
{
	char **path_split;
	char *programPath;
	char *path;
	char **args;
	//char buffer[1024];
	int i;
	int y;

	i = 0;
	path = getenv("PATH");
	if (path != NULL)
	{
		path_split = ft_split_path(path, ':');
		i = 0;
		y = 0;
		while (path_split[i])
		{
			programPath = ft_concate(path_split[i], cmd);
			//char **args[] = {programPath, NULL};
			args = ft_add_front_list(programPath, arg);
			if (execve(programPath, args, NULL) == -1) {
				//perror("execve");
				//printf("error\n");
			}
			else
			{
				printf("\n%s\n", programPath);
				printf("success\n");
				y++;
				return (1);
			}
			i++;
		}
	}
	/*
	if (getcwd(buffer, sizeof(buffer)) != NULL)
	{

		programPath = ft_concate(buffer, cmd);
		printf("\n%s\n", programPath);
		char *args[] = {programPath, NULL};
		if (execve(buffer, args, NULL))
		{
			printf("SUCCESS\n");
			return (2);
		}
		else
		{
			printf("error");
		}
	}*/
	if (y == 0)
	{
		printf("La commande « %s » n'a pas été trouvée", cmd);

	}
	
	
	return (0);
}

int	ft_count_ocu(char *src)
{
	int i;
	int n;

	i = 0;
	n = 0;
	while (src[i])
	{
		if (src[i] == ' ')
			n++;
		i++;
	}
	return (n);
}


void ft_print_args(char **args)
{
	int i;

	i = 0;
	while (args[i])
	{
		printf("<<%s>>\n", args[i]);
		i++;
	}
}

int ft_get_next_ocu(char *src, char ocu, int n)
{
	int i;

	i = n;
	while (src[i])
	{
		if (src[i] == ocu)
			return (i);
		i++;
	}
	return (-1);
}

char **ft_split_args(char *arg)
{
	char **dest;
	int i;
	int j;
	int k;

	i = 0;
	j = 0;
	k = ft_count_ocu(arg);
	dest = malloc(sizeof(char *) * (k + 1));
	k = 0;
	if (!dest)
		return (NULL);
	while (arg[i])
	{
		if (arg[i] == ' ')
		{
			k = ft_get_next_ocu(arg, ' ', i+1);
			if (k == -1)
			{
				dest[j] = ft_substr(arg, i + 1, ft_strlen(arg) - i - 1);
			}
			else
			{
				dest[j] = ft_substr(arg, i + 1, k - i - 1);
			}
			j++;
		}
		i++;
	}
	dest[j] = NULL;
	return (dest);
}

int ft_strcmp(char *tmp1, char *tmp2)
{
	int i;

	i = 0;
	while (tmp1[i] && tmp2[i])
	{
		//printf("\n%c == %c == %d", tmp1[i], tmp2[i], tmp1[i] - tmp2[i]);
		if (tmp1[i] != tmp2[i])
		{
			return (0);
		}
		i++;
	}
	if (i == ft_strlen(tmp1))
	{
		return (1);
	}
	return 0;
}

t_env ft_check_var(char *src, t_env *lst_env)
{
	int i;

	i = 0;
	while (lst_env[i].elem)
	{
		//n = ft_strlen(lst_env[i].elem);
		if (ft_strcmp(src + 1, lst_env[i].elem) == 1)
		{
			printf("j'ai trouvé : %s\n", lst_env[i].path);
			return lst_env[i];
		}
		i++;
	}
	return (t_env){0};
}

char *ft_replace_vars(char *src, t_env *lst_env)
{
	int n;
	t_env tmp;
	n = ft_get_next_ocu(src, '$', 0);
	
	if (n != -1)
	{
		printf("\nil y a une variable d'environnement\n");
		tmp = ft_check_var(src + n, lst_env);
		printf("\n%s\n", tmp.elem);
	}
	else
	{
		printf("\nil n'y a pas de variable d'environnement\n");
	}
	return src;
}

int exec_cmd(char *src, t_env *lst_env)
{
	char *cmd;
	pid_t pid;
	int status;
	char **arg;

	///printf("l'utilisateur a écrit (%s)\n", src);
	//printf("1) je parse la ligne\n\n");
	ft_replace_vars(src, lst_env);
	arg = ft_split_args(src);
	cmd = parse_cmd(src);
	pid = fork();
	if (pid == 0)
	{
		if (ft_execv(cmd, arg) == 0)
		{
			printf("\naucun programme trouvé\n");
		}
		exit(EXIT_SUCCESS);
	}
	else
	{
		waitpid(pid, &status, 0);
	}
	return 0;
	printf("programme a cherchez : (%s)\n\n", cmd);
	printf("2) je cherche le programme correspondant\n");
	printf("3) je parse les argument\n");
	printf("4) j'execute un processe enfant du programme appeller par l'utilisateur\n");
}



void shell_emu(t_env *lst_env)
{
	char* input;

    while (1) {
        input = readline("MonShell> ");
        
        if (!input) {
            // L'utilisateur a appuyé sur Ctrl+D (EOF), quitter le shell.
            //break;
        }

        if (input[0] != '\0') {
            
			
			exec_cmd(input, lst_env);
				
            add_history(input);
        }

        // Ici, vous pouvez traiter la commande input comme bon vous semble.

        // Libérer la mémoire allouée par readline.
        free(input);
    }

    // Effacer l'historique avant de quitter (facultatif).
    clear_history();

}

int main(int argc, char **argv, char **env)
{
	int		i;
	int		n;
	t_env *lst_env;

	(void)argc;
	(void)argv;
	n = ft_count_env(env);
	lst_env = malloc(sizeof(t_env) * n);
	i = 0;
	while (i < n)
	{
		lst_env[i] = ft_split_env(env[i]);
		i++;
	}
	//ft_print_env(lst_env);
	//write(1, "\n\n\n\n\n\n", 6);
	printf("BIENVENU DANS MON MINISHELL\n");
	shell_emu(lst_env);
	return (0);
}