#include "philo.h"

t_params	*ft_init_params(int argc, char **argv)
{
	t_params	*params;

	params = malloc(sizeof(t_params));
	if (!params)
		return (NULL);
	params->number_of_philosophers = ft_atoi(argv[1]);
	params->time_to_die = ft_atoi(argv[2]);
	params->time_to_eat = ft_atoi(argv[3]);
	params->time_to_sleep = ft_atoi(argv[4]);
	params->is_dead = 0;
	params->is_printing = (pthread_mutex_t)PTHREAD_MUTEX_INITIALIZER;
	if (argc == 6)
		params->number_of_times_each_philosopher_must_eat = ft_atoi(argv[5]);
	else
		params->number_of_times_each_philosopher_must_eat = -1;
	return (params);
}

long long	ft_timestamp(void)
{
	struct timeval	tv;

	gettimeofday(&tv, NULL);
	return (tv.tv_sec * 1000 + tv.tv_usec / 1000);
}

void	ft_usleep(int ms)
{
	long int	time;

	time = ft_timestamp();
	while (ft_timestamp() - time < ms)
		usleep(ms / 10);
}

int	ft_try_eat(t_philo *philo)
{
	if (pthread_mutex_trylock(&philo->left_fork->mutex) == 0)
	{
		if (pthread_mutex_trylock(&philo->right_fork->mutex) == 0)
		{
			ft_print_action(philo, "mange");
			philo->is_eating = 1;
			ft_usleep(philo->params->time_to_eat);
			pthread_mutex_unlock(&philo->right_fork->mutex);
			pthread_mutex_unlock(&philo->left_fork->mutex);
			ft_print_action(philo, "a fini de manger");
			philo->is_eating = 0;
			philo->last_eat = ft_timestamp();
			return (1);
		}
		else
		{
			pthread_mutex_unlock(&philo->left_fork->mutex);
			return (0);
		}
	}
	return (0);
}

void	*fonction_thread(void *arg)
{
	t_philo	*philo;

	philo = (t_philo *)arg;
	ft_set_print_color(philo->id % 7 + 1);
	ft_putstr("je suis le philo ");
	ft_putnbr(((t_philo *)arg)->id);
	ft_putstr("\n");
	ft_set_print_color(0);
	philo->is_thinking = 0;
	philo->is_eating = 0;
	philo->start_time = ft_timestamp();
	philo->last_eat = ft_timestamp();
	while (1)
	{
		if (philo->params->is_dead != 0)
			pthread_exit(NULL);
		if ((int)(ft_timestamp() - philo->last_eat) > philo->params->time_to_die)
		{
			ft_print_action(philo, "est mort");
			philo->params->is_dead++;
			pthread_exit(NULL);
		}
		else if (ft_try_eat(philo) == 1)
		{
			if (philo->is_thinking == 1)
			{
				ft_print_action(philo, "aréte de penser");
				philo->is_thinking = 0;
			}
			ft_print_action(philo, "dort");
			ft_usleep(philo->params->time_to_sleep);
			ft_print_action(philo, "a fini de dormir");
			philo->is_eating = 0;
		}
		else
		{
			if (philo->is_thinking == 0)
			{
				ft_print_action(philo, "pense");
				philo->is_thinking = 1;
			}
		}
		ft_usleep(1);
	}
	pthread_exit(NULL);
}

int	main(int argc, char **argv)
{
	pthread_t	*list_thread;
	t_philo		*thread_args;
	t_fork		*forks;
	t_params	params;
	int			i;

	if (argc != 5)
	{
		printf("Error: le nombre d'argument n'est pas bon\n");
		return (1);
	}
	params = *ft_init_params(argc, argv);
	ft_print_params(&params);
	forks = malloc(sizeof(t_fork) * params.number_of_philosophers);
	i = 0;
	while (i < params.number_of_philosophers)
	{
		forks[i].id = i;
		pthread_mutex_init(&forks[i].mutex, NULL);
		i++;
	}
	list_thread = malloc(sizeof(pthread_t) * params.number_of_philosophers);
	thread_args = malloc(sizeof(t_philo) * params.number_of_philosophers);
	i = 0;
	while (i < params.number_of_philosophers)
	{
		thread_args[i].id = i;
		thread_args[i].thread_id = i;
		thread_args[i].params = &params;
		thread_args[i].left_fork = &forks[i];
		if (i == 0)
			thread_args[i].right_fork = &forks[params.number_of_philosophers - 1];
		else
			thread_args[i].right_fork = &forks[i - 1];
		pthread_create(&list_thread[i], NULL, fonction_thread, &thread_args[i]);
		i++;
	}
	i = 0;
	while (i < params.number_of_philosophers)
	{
		pthread_join(list_thread[i], NULL);
		i++;
	}
	ft_putstr("\n\nfin\n");
	i = 0;
	while (i < params.number_of_philosophers)
	{
		pthread_mutex_destroy(&forks[i].mutex);
		i++;
	}

	//détuit les threads
	i = 0;
	while (i < params.number_of_philosophers)
	{
		pthread_detach(list_thread[i]);
		i++;
	}

	//free les parametres
	pthread_mutex_destroy(&params.is_printing);

	free(list_thread);
	free(thread_args);
	free(forks);
	return (0);
}
