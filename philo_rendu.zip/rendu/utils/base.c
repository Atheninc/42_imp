#include "philo.h"

int	ft_strlen(char *str)
{
	int	i;

	i = 0;
	while (str[i])
		i++;
	return (i);
}

void	ft_putstr(char *str)
{
	write(1, str, ft_strlen(str));
}

void	ft_put_nbr(int nb)
{
	char	c;

	if (nb < 0)
	{
		write(1, "-", 1);
		nb = -nb;
	}
	if (nb >= 10)
		ft_put_nbr(nb / 10);
	c = nb % 10 + '0';
	write(1, &c, 1);
}

void	ft_putnbr(long long nb)
{
	char	c;

	if (nb < 0)
	{
		write(1, "-", 1);
		nb = -nb;
	}
	if (nb >= 10)
		ft_put_nbr(nb / 10);
	c = nb % 10 + '0';
	write(1, &c, 1);
}

int ft_atoi(const char *str) {
    int result;
    int sign;

	result = 0;
	sign = 1;
    while (*str == ' ')
        str++;
    if (*str == '-' || *str == '+')
        sign = (*str++ == '-') ? -1 : 1;

    while (*str >= '0' && *str <= '9')
        result = result * 10 + (*str++ - '0');
    return result * sign;
}