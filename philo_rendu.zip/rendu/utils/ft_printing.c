#include "philo.h"

void	ft_print_params(t_params *params)
{
	ft_putstr("parametres:\n");
	ft_putstr("nombre de philosopher: ");
	ft_put_nbr(params->number_of_philosophers);
	ft_putstr("\n");
	ft_putstr("meur en : ");
	ft_put_nbr(params->time_to_die);
	ft_putstr("\n");
	ft_putstr("mange en : ");
	ft_put_nbr(params->time_to_eat);
	ft_putstr("\n");
	ft_putstr("dort en : ");
	ft_put_nbr(params->time_to_sleep);
	ft_putstr("\n");
	if (params->number_of_times_each_philosopher_must_eat != -1)
	{
		ft_putstr("doit manger : ");
		ft_put_nbr(params->number_of_times_each_philosopher_must_eat);
		ft_putstr("\n");
	}
}

void	ft_set_print_color(int color)
{
	if (color == 0)
		ft_putstr("\033[0m");
	else if (color == 1)
		ft_putstr("\033[31m");
	else if (color == 2)
		ft_putstr("\033[32m");
	else if (color == 3)
		ft_putstr("\033[33m");
	else if (color == 4)
		ft_putstr("\033[34m");
	else if (color == 5)
		ft_putstr("\033[35m");
	else if (color == 6)
		ft_putstr("\033[36m");
	else if (color == 7)
		ft_putstr("\033[37m");
}

void	ft_print_action(t_philo *philo, char *str)
{
	if (pthread_mutex_trylock(&philo->params->is_printing) != 0)
	{
		while (pthread_mutex_trylock(&philo->params->is_printing) != 0)
			usleep(1);
	}
	ft_set_print_color(philo->id % 7 + 1);
	ft_putnbr(ft_timestamp() - philo->start_time);
	ft_putstr(" ");
	ft_putnbr(philo->id);
	ft_putstr(" ");
	ft_putstr(str);
	ft_putstr("\n");
	ft_set_print_color(0);
	pthread_mutex_unlock(&philo->params->is_printing);
}

void	ft_print_fork_action(t_philo *philo, char *str, int fork_id)
{
	if (pthread_mutex_trylock(&philo->params->is_printing) != 0)
	{
		while (pthread_mutex_trylock(&philo->params->is_printing) != 0)
			usleep(1);
	}
	ft_set_print_color(philo->id % 7 + 1);
	ft_putnbr(ft_timestamp() - philo->start_time);
	ft_putstr(" ");
	ft_putnbr(philo->id);
	ft_putstr(" ");
	ft_putstr(str);
	ft_putnbr(fork_id);
	ft_putstr("\n");
	ft_set_print_color(0);
	pthread_mutex_unlock(&philo->params->is_printing);
}
