#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/time.h>

typedef struct s_params
{
	int				number_of_philosophers;
	int				time_to_die;
	int				time_to_eat;
	int				time_to_sleep;
	int				number_of_times_each_philosopher_must_eat;
	pthread_mutex_t	is_printing;
	int				is_dead;
}	t_params;

typedef struct s_fork
{
	int				id;
	pthread_mutex_t	mutex;
}	t_fork;

typedef struct s_philo
{
	int			thread_id;
	int			id;
	t_params	*params;
	t_fork		*left_fork;
	t_fork		*right_fork;
	int			is_eating;
	int			last_eat;
	long long	start_time;
	int			is_thinking;
}	t_philo;

int	ft_strlen(char *str);
int ft_atoi(const char *str);
void	ft_putstr(char *str);
void	ft_put_nbr(int nb);
void	ft_putnbr(long long nb);
void	ft_print_params(t_params *params);
void	ft_set_print_color(int color);
void	ft_print_action(t_philo *philo, char *str);
void	ft_print_fork_action(t_philo *philo, char *str, int fork_id);
long long	ft_timestamp(void);
void	ft_usleep(int ms);
int	ft_try_eat(t_philo *philo);
void	*fonction_thread(void *arg);